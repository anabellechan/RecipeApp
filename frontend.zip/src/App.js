import React from "react";
import { BrowserRouter as Router, Route, Routes, useHistory } from "react-router-dom";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import CreatePost from "./pages/CreatePost";
import MainPage from "./pages/MainPage";
import Post from "./pages/Post";
import NavDropdown from "react-bootstrap/NavDropdown";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";

const App = () => {
  return (
    <Router>
      <div className="topnav">
        {/* <nav className="navbar is-light" role="navigation" aria-label="main navigation">
          <div className="container">
            <div className="navbar-brand">
              <img src="https://1000logos.net/wp-content/uploads/2022/11/Shopee-Food-Emblem.png" width="150" height="55" alt="logo" />
              Recipe App
              <a className="navbar-item"></a>
              <a href="/" className="navbar-item">
                Recipes
              </a>
              <a href="/createpost" className="navbar-item">
                Create Post
              </a>
            </div>
          </div>
        </nav> */}

        <Navbar bg="light" expand="lg">
          <Container fluid>
            <img src="https://1000logos.net/wp-content/uploads/2022/11/Shopee-Food-Emblem.png" width="150" height="55" alt="logo" />
            <Navbar.Brand href="/">Recipe App</Navbar.Brand>
            <Navbar.Toggle aria-controls="navbarScroll" />
            <Navbar.Collapse id="navbarScroll">
              <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: "200px" }} navbarScroll>
                <Nav.Link href="/">Home</Nav.Link>
                <NavDropdown title="Recipes" id="navbarScrollingDropdown" enabled>
                  <NavDropdown.Item href="/">All</NavDropdown.Item>
                  <NavDropdown.Item href="/">Italian</NavDropdown.Item>
                  <NavDropdown.Item href="/">Japanese</NavDropdown.Item>
                  <NavDropdown.Item href="/">Korean</NavDropdown.Item>
                  <NavDropdown.Item href="/">Singaporean</NavDropdown.Item>
                  <NavDropdown.Item href="/">Thai</NavDropdown.Item>
                  <NavDropdown.Divider />
                  <NavDropdown.Item href="/">Report an Issue</NavDropdown.Item>
                </NavDropdown>
                <Nav.Link href="/createpost" enabled>
                  Create Post
                </Nav.Link>
                <Nav.Link href="/" enabled>
                  About
                </Nav.Link>
                <Nav.Link href="/" enabled>
                  Contact
                </Nav.Link>
              </Nav>
              <Form className="d-flex">
                <Form.Control type="search" placeholder="Search" className="me-2" aria-label="Search" />
                <Button variant="outline-success">Search</Button>
              </Form>
            </Navbar.Collapse>
          </Container>
        </Navbar>

        <Routes>
          <Route path="/" element={<MainPage />} />
          {/* 👇️ handle dynamic path */}
          <Route path="/createpost" element={<CreatePost />} />
          <Route path="/post/:postId" element={<Post />} />
          <Route
            path="*"
            element={
              <div>
                <h2>404 Page not found etc</h2>
              </div>
            }
          />
        </Routes>
      </div>
    </Router>
  );
};
{
  /* <Router>
  <Route path="/" exact render={(props) => <MainPage />} />
  <Route path="/createpost" render={(props) => <CreatePost />} />
  <Route path="/post/:postId" render={(props) => <Post />} />
</Router>; */
}
export default App;
