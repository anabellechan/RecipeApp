import React, { useState, useEffect } from "react";
import Axios from "axios";
import { useNavigate } from "react-router-dom";
import "../App.css";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import american from "./images/cuisines/American.png";
import italian from "./images/cuisines/Italian.png";
import jap from "./images/cuisines/Japanese.png";
import korean from "./images/cuisines/Korean.png";
import sgean from "./images/cuisines/Singaporean2.png";
import thai from "./images/cuisines/Thai.png";
import { AnimatePresence, motion } from "framer-motion/dist/framer-motion";

function MainPage() {
  const [postList, setPostList] = useState([]);

  let navigate = useNavigate();

  useEffect(() => {
    Axios.get("http://localhost:3002/api/get").then((data) => {
      console.log(data);
      setPostList(data.data);
    });
  }, []);

  const LikePost = async (id) => {
    try {
      await Axios.post(`http://localhost:3002/api/like/${id}`).then((response) => {
        alert("You liked a post!");
        window.location.reload(false);
      });
    } catch (error) {
      alert(error, "ERROR");
    }
  };

  return (
    <div className="MainPage">
      {/* <div className="cuisine-navbar">
        Click the logo to navigate to the site
        <br />
        <br />
        <a>Hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii</a>
        <a href="https://codingbeautydev.com" target="_blank" rel="noreferrer">
          <img src={italian} height="48%" width="8%" alt="italian cuisine" class="cuisine-navbar rounded-corners"></img>
        </a>
        <a href="https://codingbeautydev.com" target="_blank" rel="noreferrer">
          <img src={jap} height="48%" width="8%" alt="japanese cuisine" class="cuisine-navbar rounded-corners"></img>
        </a>
        <a href="https://codingbeautydev.com" target="_blank" rel="noreferrer">
          <img src={korean} height="48%" width="8%" alt="korean cuisine" class="cuisine-navbar rounded-corners"></img>
        </a>
        <a href="https://codingbeautydev.com" target="_blank" rel="noreferrer">
          <img src={sgean} height="48%" width="8%" alt="singaporean cuisine" class="cuisine-navbar rounded-corners"></img>
        </a>
        <a href="https://codingbeautydev.com" target="_blank" rel="noreferrer">
          <img src={thai} height="48%" width="8%" alt="thai cuisine" class="cuisine-navbar rounded-corners"></img>
        </a>
      </div> */}
      <div className="PostContainer">
        {postList.map((val, key) => {
          return (
            <Card className="col-auto mx-auto mb-5" style={{ width: "25rem" }}>
              <Card.Img variant="top" src={val.imgsrc} height="50%" width="60%" />
              <Card.Body>
                <Card.Title>
                  <h3 className="post-title" onClick={() => navigate(`/post/${val.id}`)}>
                    {val.title}
                  </h3>
                </Card.Title>
                <Card.Text>
                  <p>{val.post_subtitle}</p>
                  <h6>Written by: {val.user_name}</h6>
                </Card.Text>
                <Button variant="primary" onClick={() => navigate(`/post/${val.id}`)}>
                  Read More
                </Button>
                <button type="button" onClick={() => LikePost(val.id)} class="btn btn-light">
                  Likes: {val.likes}
                </button>
              </Card.Body>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default MainPage;
