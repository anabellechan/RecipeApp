import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Axios from "axios";
import "../App.css";
import { useNavigate } from "react-router-dom";
import Button from "react-bootstrap/Button";

export default function Post() {
  let { postId } = useParams();
  const [post, setPost] = useState({});
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [desc, setDesc] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [directions, setDirections] = useState("");
  const [notes, setNotes] = useState("");
  const [text, setText] = useState("");
  let navigate = useNavigate();

  useEffect(() => {
    Axios.get(`http://localhost:3002/api/getFromId/${postId}`).then((data) => {
      setPost({
        title: data.data[0].title,
        postText: data.data[0].post_text,
        userName: data.data[0].user_name,
        id: data.data[0].id,
        imgsrc: data.data[0].imgsrc,
        subtitle: data.data[0].post_subtitle,
        desc: data.data[0].post_desc,
        ingredients: data.data[0].post_ingredients,
        directions: data.data[0].post_directions,
        notes: data.data[0].post_notes,
      });
    });
  }, [postId]);

  const deletePost = (id) => {
    Axios.delete(`http://localhost:3002/api/delete/${postId}`).then((response) => {
      alert("you deleted a post");
    });
  };

  return (
    <div className="Post individual">
      {/* <h1 className="eachpost-title">{post.title}</h1> */}
      <div className="flex">
        <img className="circularimage" src={post.imgsrc} width="60%" height="60% "></img>
        <h10 className="post-subtitle">{post.subtitle}</h10>
      </div>
      <div>
        <p className="posttitle">{post.title}</p>
        <h4 className="eachpost">{post.desc}</h4>
        <p className="posttitle">Ingredients</p>
        <p className="eachpost">{post.ingredients}</p>
        <p className="posttitle">Directions</p>
        <p className="eachpost">{post.directions}</p>
        <p className="posttitle">Notes</p>
        <p className="eachpost">{post.notes}</p>
      </div>
      <div className="SearchBar-submit flex-c">
        <h6>Written by: {post.userName}</h6>
        <button onClick={() => navigate(`/`)} class="btn btn-light">
          Return
        </button>
      </div>
    </div>
  );
}
