import React, { useState, useEffect } from "react";
import Axios from "axios";
import "../App.css";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

function CreatePost() {
  const [userName, setUserName] = useState("");
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [desc, setDesc] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [directions, setDirections] = useState("");
  const [notes, setNotes] = useState("");
  const [text, setText] = useState("");
  const [cuisine, setCuisine] = useState("");
  const [imgsrc, setimgSrc] = useState("https://media.istockphoto.com/id/903533082/vector/abstract-gray-background.jpg?s=612x612&w=0&k=20&c=4Voiv87FE56PeR5cZTBH7y_6rwPG4jaWD6ERIbSfbpk=");
  //Blank photo if post submission photo is blank

  const submitPost = () => {
    console.log("I pressed post", userName, title, text, cuisine, imgsrc);
    Axios.post("http://localhost:3002/api/create", {
      userName: userName,
      title: title,
      text: text,
      cuisine: cuisine,
      imgsrc: imgsrc,
      subtitle: subtitle,
      desc: desc,
      ingredients: ingredients,
      directions: directions,
      notes: notes,
    });
    alert("Submitted Post");
    window.location.href = "/";
  };

  return (
    <div className="CreatePost">
      <div className="uploadPost">
        <div className="container">
          <div className="columns is-centered">
            <div className="column is-4-desktop">
              <Form>
                <Form.Group className="mb-10" controlId="formBasicEmail">
                  <Form.Label>Username</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Username"
                    onChange={(e) => {
                      setUserName(e.target.value);
                    }}
                  />
                  {/* <Form.Text className="text-muted">We</Form.Text> */}
                </Form.Group>

                <Form.Group className="mb-10">
                  <Form.Label>Post Title</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Title"
                    onChange={(e) => {
                      setTitle(e.target.value);
                    }}
                  />
                  <Form.Group className="mb-10">
                    <Form.Label>Sub-Title</Form.Label>
                    <Form.Check>
                      <textarea
                        placeholder="A secondary title for a brief description"
                        rows="6"
                        cols="20"
                        onChange={(e) => {
                          setSubtitle(e.target.value);
                        }}
                      ></textarea>
                    </Form.Check>
                  </Form.Group>
                </Form.Group>
                <Form.Group className="mb-10">
                  <Form.Label>Insert an Image URL</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Image URL"
                    onChange={(e) => {
                      setimgSrc(e.target.value);
                    }}
                  />
                </Form.Group>
                <Form.Group className="mb-10">
                  <Form.Label>Post Description</Form.Label>
                  <Form.Check>
                    <textarea
                      rows="6"
                      cols="50"
                      onChange={(e) => {
                        setDesc(e.target.value);
                      }}
                    ></textarea>
                  </Form.Check>
                </Form.Group>
                <Form.Group className="mb-10">
                  <Form.Label>Ingredients</Form.Label>
                  <Form.Check>
                    <textarea
                      rows="6"
                      cols="50"
                      onChange={(e) => {
                        setIngredients(e.target.value);
                      }}
                    ></textarea>
                  </Form.Check>
                </Form.Group>
                <Form.Group className="mb-10">
                  <Form.Label>Directions</Form.Label>
                  <Form.Check>
                    <textarea
                      rows="6"
                      cols="50"
                      onChange={(e) => {
                        setDirections(e.target.value);
                      }}
                    ></textarea>
                  </Form.Check>
                </Form.Group>
                <Form.Group className="mb-10">
                  <Form.Label>Notes</Form.Label>
                  <Form.Check>
                    <textarea
                      rows="6"
                      cols="50"
                      onChange={(e) => {
                        setNotes(e.target.value);
                      }}
                    ></textarea>
                  </Form.Check>
                </Form.Group>
                <Form.Group className="mb-10">
                  <Form.Label>
                    Select Cuisine Type <br></br>
                  </Form.Label>
                  <Form.Check>
                    <select onChange={(e) => setCuisine(e.target.value)}>
                      <option value=" "></option>
                      <option value="Italian">Italian</option>
                      <option value="Japanese">Japanese</option>
                      <option value="Korean">Korean</option>
                      <option value="Singaporean">Singaporean</option>
                      <option value="Thai">Thai</option>
                      <option value="Fusion">Fusion</option>
                    </select>
                  </Form.Check>
                </Form.Group>
                <Form.Group>
                  <Form.Check>
                    <br></br>
                    <Button
                      variant="primary"
                      type="submit"
                      onClick={(e) => {
                        submitPost();
                      }}
                    >
                      Submit
                    </Button>
                  </Form.Check>
                </Form.Group>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CreatePost;
