var mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "cdefg2",
  database: "blog_posts",
});
db.connect((err) => {
  if (err) {
    console.log(err);
    throw err;
  }
  console.log("it worked to MYSQL");
});
module.exports = db;
