const express = require("express");
const db = require("./config/db");
const cors = require("cors");

const app = express();

const PORT = 3002;
app.use(cors());
app.use(express.json());

// Route to get all posts
app.get("/api/get", (req, res) => {
  db.query("SELECT * FROM posts", (err, result) => {
    if (err) {
      console.log(err);
    }
    res.send(result);
  });
});

// Route to get one post
app.get("/api/getFromId/:id", (req, res) => {
  const id = req.params.id;
  db.query("SELECT * FROM posts WHERE id = ?", id, (err, result) => {
    if (err) {
      console.log(err);
    }
    res.send(result);
  });
});

// Route for creating the post
app.post("/api/create", (req, res) => {
  const username = req.body.userName;
  const title = req.body.title;
  const text = req.body.text;
  const cuisine = req.body.cuisine;
  const imgsrc = req.body.imgsrc;
  const subtitle = req.body.subtitle;
  const desc = req.body.desc;
  const ingredients = req.body.ingredients;
  const directions = req.body.directions;
  const notes = req.body.notes;

  console.log(username, title, text, cuisine, imgsrc, subtitle, desc, ingredients, directions, notes);

  db.query("INSERT INTO posts (title, user_name, cuisine, imgsrc, post_subtitle, post_desc, post_ingredients, post_directions, post_notes) VALUES (?,?,?,?,?,?,?,?,?)", [title, username, cuisine, imgsrc, subtitle, desc, ingredients, directions, notes], (err, result) => {
    if (err) {
      console.log(err);
    }
    console.log(result);
  });
});
// Route for like
app.post("/api/like/:id", async (req, res) => {
  const id = req.params.id;
  db.query("UPDATE posts SET likes = likes + 1 WHERE id = ?", id, (err, result) => {
    if (err) {
      console.log(err);
    }
    console.log(result);
    res.send({ message: "You liked the post!", results: result });
  });
});

// Route to delete a post

app.delete("/api/delete/:id", (req, res) => {
  const id = req.params.id;

  db.query("DELETE FROM posts WHERE id= ?", id, (err, result) => {
    if (err) {
      console.log(err);
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on ${PORT}`);
});
